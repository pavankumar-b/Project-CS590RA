Configuration files for setting up storm with [supervisord](http://supervisord.org/)
