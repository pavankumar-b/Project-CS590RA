from django.contrib import admin
from web.models import ClusterData

admin.site.register(ClusterData)
