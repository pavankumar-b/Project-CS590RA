"""Will read tweets for a cluster and generate "topics" """

def find_topics(ml_cluster):
    return []
