This is the storm application for real-time analysis of religious tweets.

# To Build

    $ git clone proj.git
    $ cd habakkuk/java/habakkuk-core
    $ mvn compile
    $ mvn package

# To Run

    $ storm jar target/habakkuk-core-0.0.1-SNAPSHOT-jar-with-dependencies.jar technicalelvis.habakkuk.MainTopology habakkuk.properties

# Configuration:
Please reference habakkuk.properties.template for example configurations and details.


# Sub-Directories
* src - java source
* multilang/resources - python bolt source
