package com.example.tweetanalysis;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.model.CategorySeries;
import org.achartengine.renderer.DefaultRenderer;
import org.achartengine.renderer.SimpleSeriesRenderer;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.ActionBarActivity;

public class visualization extends ActionBarActivity{
	private static Context context;
	private GraphicalView mChartView;
	public Intent visualization(Context context,int[] count){
		//visualization.context = getApplicationContext();
		
		System.out.println("inside visualization class>>>>");
		
		String[] labels=new String[]{"positive tweets","negative tweets"};
		 int[] clrs={Color.BLUE,Color.GRAY};
		 
		
		 CategorySeries categorySeries=new CategorySeries("Report on mood of the tweets");
		 for(int i=0;i<labels.length;i++){
			categorySeries.add(labels[i],count[i]);		
		 }
		 System.out.println("inside visualization class   2>>>>");
		 DefaultRenderer defaultRenderer = new DefaultRenderer();
		 defaultRenderer.setChartTitle("Report on mood of the tweets");
		 defaultRenderer.setChartTitleTextSize(30);
		 defaultRenderer.setZoomButtonsVisible(false);
		 System.out.println("inside visualization class   3>>>>"); 
		for(int i=0; i<labels.length; i++) {
		    SimpleSeriesRenderer simpleSeriesRenderer = new SimpleSeriesRenderer();
		    simpleSeriesRenderer.setColor(clrs[i]);
		    simpleSeriesRenderer.setDisplayChartValues(true);
		    defaultRenderer.addSeriesRenderer(simpleSeriesRenderer);
		}
		System.out.println("inside visualization class   4>>>>");
		//mChartView=ChartFactory.getDoughnutChartView(context, categorySeries, defaultRenderer);
		mChartView=ChartFactory.getPieChartView(context, categorySeries, defaultRenderer);
		System.out.println("inside visualization class   4-1>>>>");
		Intent intPiechart;
		return intPiechart=ChartFactory.getPieChartIntent(context, categorySeries, defaultRenderer, "Report on mood of the tweets");
		//startActivity(intPiechart);
		//System.out.println("inside visualization class   5>>>>");
	}
	public void main(String[] args) {
		
	}
	
}
